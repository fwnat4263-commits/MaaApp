package com.maaapp;

import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.*;
import android.content.SharedPreferences;
import android.location.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BLUE=Color.rgb(16,132,214), DARK=Color.rgb(27,55,78), BG=Color.rgb(246,250,254), GREEN=Color.rgb(26,157,91), LIGHT=Color.rgb(232,243,251);
    private int quantity=1;
    private double latitude=0, longitude=0;
    private String locationText="لم يتم تحديد الموقع";
    private LocationManager locationManager;
    private SharedPreferences prefs;
    private Typeface arabicFont;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,101,175));
        prefs=getSharedPreferences("maa",MODE_PRIVATE);
        try{ arabicFont=Typeface.createFromAsset(getAssets(),"fonts/Omati Italic.otf"); }catch(Exception e){ arabicFont=Typeface.create("sans",Typeface.NORMAL); }
        showHome();
    }

    private TextView label(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setTypeface(arabicFont,bold?Typeface.BOLD:Typeface.NORMAL); t.setIncludeFontPadding(true); return t;
    }
    private GradientDrawable box(int color,float r){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(r); return d; }
    private Button btn(String s,int color){ Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTypeface(arabicFont,Typeface.BOLD); b.setBackground(box(color,24)); return b; }
    private LinearLayout page(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackgroundColor(BG); return l; }
    private LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout.LayoutParams p(int h){ return new LinearLayout.LayoutParams(-1,h); }

    private void showHome(){
        LinearLayout root=page();
        TextView header=label("💧  ماء",29,Color.WHITE,true); header.setBackground(box(BLUE,0)); root.addView(header,p(70));
        ScrollView sv=new ScrollView(this); LinearLayout c=vertical(); c.setPadding(18,18,18,20);

        TextView welcome=label("هلا بيك 👋\nاطلب ماي... يوصلك للبيت",25,DARK,true); welcome.setGravity(Gravity.CENTER); LinearLayout.LayoutParams wp=p(92); wp.setMargins(0,0,0,12); c.addView(welcome,wp);
        ImageView image=new ImageView(this); image.setImageResource(R.drawable.maa_app_image); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackground(box(Color.WHITE,22)); LinearLayout.LayoutParams ip=p(205); ip.setMargins(0,0,0,14); c.addView(image,ip);

        TextView hero=label("أبو الماي بالطريق إلك 🚚",23,Color.WHITE,true); hero.setBackground(box(BLUE,24)); LinearLayout.LayoutParams hp=p(66); hp.setMargins(0,0,0,14); c.addView(hero,hp);

        Button order=btn("💧  اطلب ماء الآن",GREEN); LinearLayout.LayoutParams op=p(64); op.setMargins(0,0,0,12); c.addView(order,op); order.setOnClickListener(v->showOrder());

        LinearLayout price=vertical(); price.setPadding(16,12,16,12); price.setBackground(box(Color.WHITE,22));
        price.addView(label("أسعار الجلكان 20 لتر",20,DARK,true),p(42));
        price.addView(label("1 جلكان     500 د.ع",17,DARK,false),p(36));
        price.addView(label("2 جلكان     850 د.ع",17,DARK,false),p(36));
        price.addView(label("3 جلكانات   1,250 د.ع",17,DARK,false),p(36));
        LinearLayout.LayoutParams pp=p(165); pp.setMargins(0,0,0,12); c.addView(price,pp);

        TextView how=label("طريقة الطلب\n\n① اختر عدد الجلكانات\n② حدد موقع بيتك على الخريطة\n③ أكد الطلب\n④ أبو الماي يستلم ويوصل لك",17,DARK,false); how.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); how.setPadding(20,12,20,12); how.setBackground(box(Color.WHITE,22)); LinearLayout.LayoutParams hw=p(190); hw.setMargins(0,0,0,12); c.addView(how,hw);

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(4,0,4,0);
        Button orders=btn("📋 طلباتي",BLUE), account=btn("👤 حسابي",BLUE), contact=btn("📞 اتصل بنا",BLUE);
        nav.addView(orders,new LinearLayout.LayoutParams(0,58,1)); nav.addView(account,new LinearLayout.LayoutParams(0,58,1)); nav.addView(contact,new LinearLayout.LayoutParams(0,58,1));
        orders.setOnClickListener(v->showCustomerStatus()); account.setOnClickListener(v->showLogin()); contact.setOnClickListener(v->showComplaints()); c.addView(nav,p(64));

        Button driver=btn("🚚 واجهة أبو الماي",DARK); LinearLayout.LayoutParams dp=p(58); dp.setMargins(0,12,0,0); c.addView(driver,dp); driver.setOnClickListener(v->showDriver());
        sv.addView(c); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private int priceForQuantity(int q){ if(q==1)return 500; if(q==2)return 850; if(q==3)return 1250; return 1250+(q-3)*400; }

    private void showOrder(){
        LinearLayout root=page(); TextView top=label("اطلب ماء",25,Color.WHITE,true); top.setBackground(box(BLUE,0)); root.addView(top,p(70));
        LinearLayout c=vertical(); c.setPadding(20,20,20,20);
        TextView title=label("جلكان ماء 20 لتر",25,DARK,true); c.addView(title,p(62));
        TextView hint=label("اختَر عدد الجلكانات",18,Color.DKGRAY,false); c.addView(hint,p(48));
        LinearLayout cards=new LinearLayout(this); cards.setGravity(Gravity.CENTER); cards.setPadding(0,8,0,8);
        int[] nums={1,2,3};
        for(int n:nums){ Button q=btn(n+"\n"+(n==1?"500 د.ع":n==2?"850 د.ع":"1,250 د.ع"),n==quantity?BLUE:Color.rgb(112,168,205)); LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,90,1); qp.setMargins(5,0,5,0); cards.addView(q,qp); final int x=n; q.setOnClickListener(v->{quantity=x; showOrder();}); }
        c.addView(cards,p(100));
        TextView total=label("المجموع: "+priceForQuantity(quantity)+" د.ع",23,GREEN,true); total.setBackground(box(Color.WHITE,20)); LinearLayout.LayoutParams tp=p(66); tp.setMargins(0,8,0,14); c.addView(total,tp);
        Button loc=btn("📍  حدد موقع بيتك على الخريطة",BLUE); c.addView(loc,p(64)); loc.setOnClickListener(v->showLocation());
        TextView note=label("بعد تحديد الموقع راح تشوف الطلب قبل الإرسال.",16,DARK,false); note.setGravity(Gravity.CENTER); c.addView(note,p(55));
        Button back=btn("رجوع",Color.GRAY); LinearLayout.LayoutParams bp=p(56); bp.setMargins(0,14,0,0); c.addView(back,bp); back.setOnClickListener(v->showHome());
        root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showLocation(){
        LinearLayout root=page(); TextView top=label("حدد موقع بيتك",24,Color.WHITE,true); top.setBackground(box(BLUE,0)); root.addView(top,p(70));
        LinearLayout c=vertical(); c.setPadding(12,12,12,12);
        c.addView(label("اضغط على الخريطة واختَر مكان بيتك",18,DARK,true),p(50));
        WebView map=new WebView(this); WebSettings s=map.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        map.addJavascriptInterface(new Object(){ @android.webkit.JavascriptInterface public void pick(double lat,double lon){ latitude=lat; longitude=lon; locationText=String.format(Locale.US,"%.6f , %.6f",lat,lon); } },"Android");
        String html="<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'><style>html,body,#map{height:100%;margin:0}</style></head><body><div id='map'></div><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script><script>var map=L.map('map').setView([31.05,46.26],13);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);var m;function pick(a,b){if(m)m.setLatLng([a,b]);else m=L.marker([a,b]).addTo(map);Android.pick(a,b)}map.on('click',e=>pick(e.latlng.lat,e.latlng.lng));</script></body></html>";
        map.loadDataWithBaseURL(null,html,"text/html","UTF-8",null); c.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        TextView selected=label("الموقع: "+locationText,16,DARK,true); selected.setBackground(box(Color.WHITE,18)); LinearLayout.LayoutParams sp=p(58); sp.setMargins(0,10,0,8); c.addView(selected,sp);
        Button confirm=btn("تأكيد الموقع",GREEN); c.addView(confirm,p(62)); confirm.setOnClickListener(v->{ if(latitude==0&&longitude==0){selected.setText("اختَر نقطة على الخريطة أولاً");} else showConfirm(); });
        Button back=btn("رجوع",Color.GRAY); LinearLayout.LayoutParams bp=p(54); bp.setMargins(0,8,0,0); c.addView(back,bp); back.setOnClickListener(v->showOrder());
        root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showConfirm(){
        LinearLayout root=page(); TextView top=label("تأكيد الطلب",24,Color.WHITE,true); top.setBackground(box(BLUE,0)); root.addView(top,p(70));
        LinearLayout c=vertical(); c.setPadding(20,22,20,20);
        TextView card=label("عدد الجلكانات: "+quantity+"\n\nالمجموع: "+priceForQuantity(quantity)+" د.ع\n\nالموقع: "+locationText+"\n\nالدفع: عند الاستلام",19,DARK,true); card.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); card.setPadding(22,18,22,18); card.setBackground(box(Color.WHITE,22)); c.addView(card,p(260));
        Button send=btn("إرسال الطلب إلى أبو الماي",GREEN); LinearLayout.LayoutParams sp=p(64); sp.setMargins(0,18,0,10); c.addView(send,sp); send.setOnClickListener(v->{prefs.edit().putInt("quantity",quantity).putInt("total",priceForQuantity(quantity)).putString("location",locationText).putFloat("lat",(float)latitude).putFloat("lon",(float)longitude).putString("status","جديد").apply(); showCustomerStatus();});
        Button back=btn("تعديل الطلب",Color.GRAY); c.addView(back,p(56)); back.setOnClickListener(v->showOrder());
        root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showCustomerStatus(){
        LinearLayout root=page(); TextView top=label("طلباتي",24,Color.WHITE,true); top.setBackground(box(BLUE,0)); root.addView(top,p(70));
        LinearLayout c=vertical(); c.setPadding(20,22,20,20); String status=prefs.getString("status","");
        if(status.isEmpty()) c.addView(label("ما عندك طلبات حالياً\n\nاضغط «اطلب ماء الآن» من الرئيسية.",20,DARK,true),p(180));
        else { int q=prefs.getInt("quantity",1), total=prefs.getInt("total",priceForQuantity(q)); TextView card=label("طلبك الحالي\n\nالجلكانات: "+q+"\nالمجموع: "+total+" د.ع\n\nالحالة: "+status,20,DARK,true); card.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); card.setPadding(22,20,22,20); card.setBackground(box(Color.WHITE,22)); c.addView(card,p(270)); }
        Button home=btn("الرئيسية",BLUE); LinearLayout.LayoutParams hp=p(60); hp.setMargins(0,18,0,0); c.addView(home,hp); home.setOnClickListener(v->showHome()); root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showLogin(){
        LinearLayout root=page(); TextView top=label("حسابي",24,Color.WHITE,true); top.setBackground(box(BLUE,0)); root.addView(top,p(70)); LinearLayout c=vertical(); c.setPadding(20,24,20,20);
        c.addView(label("تسجيل الدخول برقم الهاتف",21,DARK,true),p(60)); EditText phone=new EditText(this); phone.setHint("رقم الهاتف"); phone.setGravity(Gravity.RIGHT); phone.setInputType(2); c.addView(phone,p(62));
        Button send=btn("إرسال كود التحقق",BLUE); c.addView(send,p(62)); EditText code=new EditText(this); code.setHint("كود التحقق"); code.setGravity(Gravity.RIGHT); code.setInputType(2); c.addView(code,p(62));
        Button enter=btn("دخول",GREEN); c.addView(enter,p(62)); enter.setOnClickListener(v->{prefs.edit().putString("phone",phone.getText().toString()).apply(); showHome();});
        TextView note=label("واجهة تجريبية حالياً — ربط SMS الحقيقي يحتاج خدمة تحقق.",15,DARK,false); c.addView(note,p(80)); root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showComplaints(){
        LinearLayout root=page(); TextView top=label("الشكاوى والرسائل",24,Color.WHITE,true); top.setBackground(box(BLUE,0)); root.addView(top,p(70)); LinearLayout c=vertical(); c.setPadding(20,24,20,20);
        c.addView(label("اكتب رسالتك للإدارة",21,DARK,true),p(55)); EditText msg=new EditText(this); msg.setHint("اكتب الشكوى أو الملاحظة هنا..."); msg.setGravity(Gravity.RIGHT|Gravity.TOP); msg.setMinLines(6); msg.setBackground(box(Color.WHITE,20)); c.addView(msg,p(180));
        Button send=btn("إرسال الرسالة",GREEN); LinearLayout.LayoutParams sp=p(62); sp.setMargins(0,14,0,10); c.addView(send,sp); send.setOnClickListener(v->{msg.setText("تم استلام رسالتك ✓"); msg.setEnabled(false);}); Button back=btn("الرئيسية",Color.GRAY); c.addView(back,p(56)); back.setOnClickListener(v->showHome()); root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showDriver(){
        LinearLayout root=page(); TextView top=label("🚚 أبو الماي",24,Color.WHITE,true); top.setBackground(box(DARK,0)); root.addView(top,p(70)); LinearLayout c=vertical(); c.setPadding(20,20,20,20);
        int earnings=prefs.getInt("driverEarnings",0); c.addView(label("أرباح أبو الماي\n"+earnings+" د.ع من أصل 25,000 د.ع",20,DARK,true),p(100));
        String status=prefs.getString("status",""); if(status.isEmpty()||status.equals("مكتمل")) c.addView(label("ماكو طلبات جديدة حالياً",20,DARK,true),p(150));
        else { int q=prefs.getInt("quantity",1); Button accept=btn("قبول الطلب ✓",GREEN); c.addView(label("طلب جديد\n"+q+" جلكان\n"+prefs.getInt("total",priceForQuantity(q))+" د.ع\n"+prefs.getString("location","غير محدد"),19,DARK,true),p(220)); c.addView(accept,p(62)); accept.setOnClickListener(v->{prefs.edit().putString("status","أبو الماي قبل الطلب - جاري التوصيل").apply(); showDriver();}); }
        Button back=btn("الرئيسية",Color.GRAY); LinearLayout.LayoutParams bp=p(56); bp.setMargins(0,18,0,0); c.addView(back,bp); back.setOnClickListener(v->showHome()); root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
}
