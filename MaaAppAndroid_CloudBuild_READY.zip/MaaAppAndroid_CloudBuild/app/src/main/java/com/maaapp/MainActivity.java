package com.maaapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Maa\nتوصيل الماء");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(20, 100, 180));
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("تطبيق تجريبي جاهز للبناء\nيمكننا إضافة الطلبات والتوصيل والدفع لاحقاً.");
        info.setTextSize(18);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 32, 0, 32);

        Button order = new Button(this);
        order.setText("طلب ماء");
        order.setOnClickListener(v -> info.setText("تم إنشاء طلب تجريبي ✓"));

        root.addView(title);
        root.addView(info);
        root.addView(order, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}
