package com.maaapp.maa

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : Activity() {
    private var qty = 1
    private val pricePerBottle = 750
    private val locationRequestCode = 1001
    private var latitude: Double? = null
    private var longitude: Double? = null
    private var db: FirebaseFirestore? = null
    private lateinit var total: TextView
    private lateinit var locationStatus: TextView
    private lateinit var status: TextView

    private val blue = Color.rgb(14, 139, 211)
    private val dark = Color.rgb(24, 55, 75)
    private val light = Color.rgb(245, 250, 253)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = blue
        try { if (FirebaseApp.initializeApp(this) != null) db = FirebaseFirestore.getInstance() } catch (_: Exception) { db = null }
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 18, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun tv(text: String, size: Float, color: Int = dark, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_RTL
    }

    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(light) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = bg(Color.WHITE, 20)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        header.addView(tv("ماء 💧", 30, blue, true))
        header.addView(tv("ماء نظيف يوصلك للبيت", 17, dark, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        root.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = bg(blue, 20); setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        info.addView(tv("جلكان ماء RO نقي", 22, Color.WHITE, true))
        info.addView(tv("20 لتر  •  750 د.ع للجلكان", 17, Color.WHITE, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(info, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(tv("اختر الكمية", 21, dark, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val grid = GridLayout(this).apply { columnCount = 2; rowCount = 5; useDefaultMargins = false }
        for (n in 1..10) {
            val b = TextView(this).apply {
                text = "$n\nجلكان${if (n > 1) "ات" else ""}"
                textSize = 17f; gravity = Gravity.CENTER; setTextColor(if (n == qty) Color.WHITE else dark)
                typeface = Typeface.DEFAULT_BOLD
                background = bg(if (n == qty) blue else Color.WHITE, 16, if (n == qty) blue else Color.rgb(215, 230, 240))
                setPadding(dp(8), dp(12), dp(8), dp(12))
                setOnClickListener { qty = n; refreshQuantity(grid) }
            }
            val p = GridLayout.LayoutParams().apply {
                width = 0; height = dp(68); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(b, p)
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        total = tv("المجموع 750 د.ع", 23, blue, true).apply {
            background = bg(Color.WHITE, 16); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        root.addView(total, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(Color.WHITE, 18); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val name = field("اسم الزبون")
        val phone = field("رقم الهاتف").apply { inputType = InputType.TYPE_CLASS_PHONE }
        val address = field("المنطقة والعنوان").apply { minLines = 2; gravity = Gravity.TOP or Gravity.RIGHT }
        form.addView(tv("بيانات التوصيل", 19, dark, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        form.addView(name); form.addView(phone, marginTop()) ; form.addView(address, marginTop())

        val loc = Button(this).apply {
            text = "📍  تحديد موقعي"
            textSize = 17f; isAllCaps = false; setTextColor(Color.WHITE); background = bg(blue, 14)
            setOnClickListener { requestCurrentLocation() }
        }
        form.addView(loc, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        locationStatus = tv("لم يتم تحديد الموقع بعد", 14, Color.DKGRAY).apply { setPadding(0, dp(8), 0, 0) }
        form.addView(locationStatus)
        root.addView(form, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val payment = tv("💵  الدفع عند الاستلام", 18, dark, true).apply { background = bg(Color.WHITE, 16); setPadding(dp(10), dp(14), dp(10), dp(14)) }
        root.addView(payment, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val order = Button(this).apply {
            text = "اطلب الماء الآن  ←"; textSize = 19f; isAllCaps = false; setTextColor(Color.WHITE); background = bg(blue, 16)
            setOnClickListener { submit(name.text.toString(), phone.text.toString(), address.text.toString()) }
        }
        root.addView(order, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(8) })

        status = tv("", 15, dark, false).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        root.addView(status)
        setContentView(scroll)
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint; textSize = 16f; setTextColor(dark); setHintTextColor(Color.GRAY); background = bg(Color.rgb(248, 251, 253), 12); setPadding(dp(14), 0, dp(14), 0)
        textDirection = View.TEXT_DIRECTION_RTL
    }

    private fun marginTop() = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) }

    private fun refreshQuantity(grid: GridLayout) {
        for (i in 0 until grid.childCount) {
            val n = i + 1; val b = grid.getChildAt(i) as TextView
            b.setTextColor(if (n == qty) Color.WHITE else dark)
            b.background = bg(if (n == qty) blue else Color.WHITE, 16, if (n == qty) blue else Color.rgb(215, 230, 240))
        }
        total.text = "المجموع ${qty * pricePerBottle} د.ع"
    }

    private fun requestCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), locationRequestCode); return
        }
        getCurrentLocation()
    }

    private fun getCurrentLocation() {
        locationStatus.text = "جاري تحديد موقعك..."
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            var location: Location? = null
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (location == null && manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) location = manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (location != null) {
                latitude = location.latitude; longitude = location.longitude
                locationStatus.text = "✅ تم تحديد موقعك بنجاح"
            } else locationStatus.text = "⚠️ شغّل GPS وخدمات الموقع ثم حاول مرة ثانية"
        } catch (_: Exception) { locationStatus.text = "⚠️ تعذر تحديد الموقع" }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationRequestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) getCurrentLocation()
        else if (requestCode == locationRequestCode) locationStatus.text = "⚠️ لم تسمح للتطبيق بالوصول للموقع"
    }

    private fun submit(name: String, phone: String, address: String) {
        if (name.isBlank() || phone.isBlank() || address.isBlank()) { status.text = "⚠️ املأ الاسم ورقم الهاتف والعنوان"; return }
        if (latitude == null || longitude == null) { status.text = "⚠️ حدد موقعك أولاً"; return }
        val data = hashMapOf<String, Any>(
            "customerName" to name, "phone" to phone, "address" to address,
            "quantity" to qty, "pricePerBottle" to pricePerBottle, "price" to qty * pricePerBottle,
            "latitude" to latitude!!, "longitude" to longitude!!, "status" to "جديد",
            "payment" to "الدفع عند الاستلام", "createdAt" to FieldValue.serverTimestamp()
        )
        val firestore = db
        if (firestore == null) { status.text = "✅ تم تسجيل الطلب تجريبيًا\n$qty جلكان • ${qty * pricePerBottle} د.ع • الدفع عند الاستلام"; return }
        status.text = "جاري إرسال الطلب..."
        firestore.collection("orders").add(data).addOnSuccessListener { ref -> status.text = "✅ تم الطلب بنجاح\nرقم الطلب: ${ref.id}" }.addOnFailureListener { e -> status.text = "❌ تعذر إرسال الطلب: ${e.message}" }
    }
}
