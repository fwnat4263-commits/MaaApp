package com.maaapp.maa

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : Activity() {
    private var qty = 1
    private var db: FirebaseFirestore? = null
    private lateinit var status: TextView
    private lateinit var total: TextView
    private lateinit var locationStatus: TextView
    private var latitude: Double? = null
    private var longitude: Double? = null
    private val pricePerBottle = 750
    private val locationRequestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (FirebaseApp.initializeApp(this) != null) db = FirebaseFirestore.getInstance()
        } catch (_: Exception) { db = null }
        showHome()
    }

    private fun showHome() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            textDirection = View.TEXT_DIRECTION_RTL
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "ماء 💧"
            textSize = 34f
            setTextColor(Color.rgb(18, 115, 150))
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 8)
        }
        val sub = TextView(this).apply {
            text = "اطلب ماي... يوصلك للبيت"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 28)
        }
        root.addView(title)
        root.addView(sub)

        val qLabel = TextView(this).apply {
            text = "عدد جلكانات الماء (20 لتر)"
            textSize = 19f
            setPadding(0, 10, 0, 8)
        }
        root.addView(qLabel)

        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        (1..10).forEach { n ->
            val b = Button(this).apply {
                text = n.toString()
                textSize = 14f
                setOnClickListener {
                    qty = n
                    total.text = "المجموع: ${qty * pricePerBottle} د.ع"
                }
            }
            val target = if (n <= 5) row1 else row2
            target.addView(b, LinearLayout.LayoutParams(0, 55, 1f).apply { setMargins(3, 3, 3, 3) })
        }
        root.addView(row1)
        root.addView(row2)

        val name = EditText(this).apply { hint = "اسم الزبون"; textSize = 17f }
        val phone = EditText(this).apply { hint = "رقم الهاتف"; inputType = 2; textSize = 17f }
        val address = EditText(this).apply {
            hint = "المنطقة والعنوان"
            minLines = 2
            gravity = Gravity.TOP
            textSize = 17f
        }
        root.addView(name)
        root.addView(phone)
        root.addView(address)

        val locationButton = Button(this).apply {
            text = "📍 تحديد موقعي الحالي"
            textSize = 18f
            setOnClickListener { requestCurrentLocation() }
        }
        root.addView(locationButton)

        locationStatus = TextView(this).apply {
            text = "لم يتم تحديد الموقع بعد"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 8)
        }
        root.addView(locationStatus)

        val payment = TextView(this).apply {
            text = "💵 طريقة الدفع: الدفع عند الاستلام"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        root.addView(payment)

        total = TextView(this).apply {
            text = "المجموع: 750 د.ع"
            textSize = 21f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 12)
        }
        root.addView(total)

        val order = Button(this).apply {
            text = "اطلب الآن"
            textSize = 19f
            setOnClickListener {
                submit(name.text.toString(), phone.text.toString(), address.text.toString())
            }
        }
        root.addView(order)

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        root.addView(status)
        setContentView(scroll)
    }

    private fun requestCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                locationRequestCode
            )
            return
        }
        getCurrentLocation()
    }

    private fun getCurrentLocation() {
        locationStatus.text = "جاري تحديد الموقع..."
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            var location: Location? = null
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                }
                if (location == null && manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    location = manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                }
            }
            if (location != null) {
                latitude = location.latitude
                longitude = location.longitude
                locationStatus.text = "✅ تم تحديد الموقع\nخط العرض: %.6f\nخط الطول: %.6f".format(latitude, longitude)
            } else {
                locationStatus.text = "⚠️ لم يتم العثور على الموقع. فعّل GPS وخدمات الموقع ثم حاول مرة ثانية."
            }
        } catch (_: Exception) {
            locationStatus.text = "⚠️ تعذر تحديد الموقع. تأكد من تشغيل GPS."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationRequestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            getCurrentLocation()
        } else if (requestCode == locationRequestCode) {
            locationStatus.text = "⚠️ لم تسمح للتطبيق بالوصول إلى الموقع"
        }
    }

    private fun submit(name: String, phone: String, address: String) {
        if (name.isBlank() || phone.isBlank() || address.isBlank()) {
            status.text = "⚠️ املأ الاسم ورقم الهاتف والعنوان"
            return
        }
        if (latitude == null || longitude == null) {
            status.text = "⚠️ حدد موقعك أولاً من زر تحديد موقعي"
            return
        }

        val data = hashMapOf<String, Any>(
            "customerName" to name,
            "phone" to phone,
            "address" to address,
            "quantity" to qty,
            "pricePerBottle" to pricePerBottle,
            "price" to qty * pricePerBottle,
            "latitude" to latitude!!,
            "longitude" to longitude!!,
            "status" to "جديد",
            "payment" to "الدفع عند الاستلام",
            "createdAt" to FieldValue.serverTimestamp()
        )

        val firestore = db
        if (firestore == null) {
            status.text = "✅ تم تسجيل الطلب تجريبيًا\nالكمية: $qty جلكان\nالمبلغ: ${qty * pricePerBottle} د.ع\nالدفع: عند الاستلام"
            return
        }
        status.text = "جاري إرسال الطلب..."
        firestore.collection("orders").add(data).addOnSuccessListener { ref ->
            status.text = "✅ تم الطلب بنجاح\nرقم الطلب: ${ref.id}\nالحالة: جديد\nالدفع: عند الاستلام"
        }.addOnFailureListener { e ->
            status.text = "❌ تعذر إرسال الطلب: ${e.message}"
        }
    }
}
