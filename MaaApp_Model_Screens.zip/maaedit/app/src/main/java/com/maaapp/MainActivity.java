package com.maaapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BLUE=Color.rgb(18,132,214), BLUE_DARK=Color.rgb(18,78,126), BG=Color.rgb(247,250,253), TEXT=Color.rgb(28,55,78), MUTED=Color.rgb(105,125,142), GREEN=Color.rgb(31,157,94), WHITE=Color.WHITE;
    private int quantity=1; private double latitude=0, longitude=0; private String locationText="لم يتم تحديد الموقع";
    private SharedPreferences prefs; private Typeface font;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BLUE_DARK); prefs=getSharedPreferences("maa",MODE_PRIVATE); font=Typeface.create("sans-serif",Typeface.NORMAL); showHome(); }

    private TextView text(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setTypeface(font,bold?Typeface.BOLD:Typeface.NORMAL); t.setIncludeFontPadding(true); return t; }
    private GradientDrawable bg(int color,float r){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(r); return d; }
    private Button button(String s,int color){ Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setTextColor(WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTypeface(font,Typeface.BOLD); b.setPadding(8,0,8,0); b.setBackground(bg(color,22)); return b; }
    private LinearLayout v(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout h(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout root(){ LinearLayout r=v(); r.setBackgroundColor(BG); return r; }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams wrap(int bottom){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,bottom); return p; }
    private void title(LinearLayout r,String s){ TextView t=text(s,23,WHITE,true); t.setBackground(bg(BLUE,0)); r.addView(t,lp(-1,64)); }

    private void showHome(){
        LinearLayout r=root(); title(r,"ماء  💧");
        ScrollView sv=new ScrollView(this); LinearLayout c=v(); c.setPadding(16,14,16,16);
        TextView welcome=text("هلا بيك 👋\nاطلب ماي... يوصلك للبيت",22,TEXT,true); welcome.setPadding(8,10,8,10); c.addView(welcome,wrap(10));
        ImageView heroImg=new ImageView(this); heroImg.setImageResource(R.drawable.maa_app_image); heroImg.setScaleType(ImageView.ScaleType.CENTER_CROP); heroImg.setBackground(bg(WHITE,20)); c.addView(heroImg,wrap(12));
        TextView hero=text("ماء نقي لصحتك\nنوصل لك الماي لباب البيت",20,BLUE_DARK,true); hero.setBackground(bg(WHITE,18)); hero.setPadding(14,12,14,12); c.addView(hero,wrap(12));
        Button order=button("اطلب ماء الآن  →",BLUE); c.addView(order,wrap(14)); order.setOnClickListener(v->showOrder());
        TextView section=text("اختَر الكمية",20,TEXT,true); section.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); c.addView(section,wrap(8));
        LinearLayout prices=h(); prices.setGravity(Gravity.CENTER); String[] names={"1 جلكان","2 جلكانات","3 جلكانات"}; String[] vals={"500 د.ع","850 د.ع","1,250 د.ع"};
        for(int i=0;i<3;i++){ LinearLayout card=v(); card.setGravity(Gravity.CENTER); card.setPadding(4,10,4,10); card.setBackground(bg(WHITE,18)); TextView a=text(names[i],16,TEXT,true); TextView b=text(vals[i],15,BLUE,true); card.addView(a,lp(-1,32)); card.addView(b,lp(-1,32)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,78,1); cp.setMargins(4,0,4,0); prices.addView(card,cp); }
        c.addView(prices,wrap(14));
        TextView info=text("توصيل داخل الناصرية\nالدفع عند الاستلام",16,MUTED,false); info.setBackground(bg(WHITE,16)); info.setPadding(10,8,10,8); c.addView(info,wrap(12));
        sv.addView(c); r.addView(sv,lp(-1,0));
        LinearLayout nav=h(); nav.setPadding(8,6,8,6); nav.setBackground(bg(WHITE,18));
        Button b1=navBtn("الرئيسية",BLUE), b2=navBtn("طلباتي",MUTED), b3=navBtn("حسابي",MUTED); nav.addView(b1,lp(0,58)); ((LinearLayout.LayoutParams)b1.getLayoutParams()).weight=1; nav.addView(b2,lp(0,58)); ((LinearLayout.LayoutParams)b2.getLayoutParams()).weight=1; nav.addView(b3,lp(0,58)); ((LinearLayout.LayoutParams)b3.getLayoutParams()).weight=1;
        b2.setOnClickListener(v->showOrders()); b3.setOnClickListener(v->showAccount()); r.addView(nav,lp(-1,70)); setContentView(r);
    }
    private Button navBtn(String s,int color){ return button(s,color); }

    private int price(int q){ return q==1?500:q==2?850:q==3?1250:1250+(q-3)*400; }

    private void showOrder(){
        LinearLayout r=root(); title(r,"اطلب ماء"); ScrollView sv=new ScrollView(this); LinearLayout c=v(); c.setPadding(18,16,18,18);
        TextView head=text("ماء RO نقي\nجلكان 20 لتر",21,TEXT,true); head.setBackground(bg(WHITE,18)); head.setPadding(16,12,16,12); c.addView(head,wrap(12));
        TextView qh=text("عدد الجلكانات",20,TEXT,true); qh.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); c.addView(qh,wrap(8));
        LinearLayout cards=h(); cards.setGravity(Gravity.CENTER);
        for(int n=1;n<=3;n++){ Button q=button(n+"\n"+price(n)+" د.ع",n==quantity?BLUE:Color.rgb(224,238,249)); if(n!=quantity) q.setTextColor(TEXT); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,92,1); p.setMargins(4,0,4,0); cards.addView(q,p); final int x=n; q.setOnClickListener(v->{quantity=x;showOrder();}); }
        c.addView(cards,wrap(14));
        TextView total=text("المجموع  "+price(quantity)+" د.ع",21,BLUE_DARK,true); total.setBackground(bg(WHITE,18)); total.setPadding(10,10,10,10); c.addView(total,wrap(14));
        Button loc=button("📍  حدد موقعك على الخريطة",BLUE); c.addView(loc,wrap(10)); loc.setOnClickListener(v->showLocation());
        Button back=button("رجوع",Color.rgb(150,160,170)); c.addView(back,wrap(8)); back.setOnClickListener(v->showHome());
        sv.addView(c); r.addView(sv,lp(-1,0)); setContentView(r);
    }

    private void showLocation(){
        LinearLayout r=root(); title(r,"حدد موقعك"); LinearLayout c=v(); c.setPadding(12,12,12,12); c.addView(text("حرّك الخريطة واضغط على مكان بيتك",18,TEXT,true),wrap(8));
        WebView map=new WebView(this); WebSettings ws=map.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        map.addJavascriptInterface(new Object(){ @android.webkit.JavascriptInterface public void pick(double lat,double lon){ latitude=lat; longitude=lon; locationText=String.format(Locale.US,"%.5f , %.5f",lat,lon); } },"Android");
        String html="<html dir='rtl'><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'><style>html,body,#map{height:100%;margin:0}</style></head><body><div id='map'></div><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script><script>var map=L.map('map').setView([31.05,46.26],13);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);var m;map.on('click',function(e){if(m)m.setLatLng(e.latlng);else m=L.marker(e.latlng).addTo(map);Android.pick(e.latlng.lat,e.latlng.lng);});</script></body></html>";
        map.loadDataWithBaseURL(null,html,"text/html","UTF-8",null); c.addView(map,lp(-1,0));
        LinearLayout bottom=v(); TextView sel=text("الموقع: "+locationText,15,TEXT,true); sel.setBackground(bg(WHITE,16)); bottom.addView(sel,wrap(8)); Button ok=button("تأكيد الموقع",BLUE); bottom.addView(ok,wrap(6)); ok.setOnClickListener(v->{if(latitude==0&&longitude==0){sel.setText("اختَر نقطة من الخريطة أولاً");}else showConfirm();}); Button back=button("رجوع",Color.rgb(150,160,170)); bottom.addView(back,lp(-1,52)); back.setOnClickListener(v->showOrder()); c.addView(bottom,lp(-1,180)); r.addView(c,lp(-1,0)); setContentView(r);
    }

    private void showConfirm(){ LinearLayout r=root(); title(r,"مراجعة الطلب"); LinearLayout c=v(); c.setPadding(18,18,18,18);
        TextView card=text("جلكان 20 لتر\n\nالكمية: "+quantity+"\nالسعر الإجمالي: "+price(quantity)+" د.ع\n\nموقع التوصيل\n"+locationText+"\n\nطريقة الدفع\nعند الاستلام",18,TEXT,true); card.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); card.setPadding(20,18,20,18); card.setBackground(bg(WHITE,20)); c.addView(card,wrap(14));
        Button send=button("إرسال الطلب",BLUE); c.addView(send,wrap(10)); send.setOnClickListener(v->{prefs.edit().putInt("quantity",quantity).putInt("total",price(quantity)).putString("location",locationText).putString("status","تم إرسال الطلب").apply();showTracking();}); Button edit=button("تعديل الطلب",Color.rgb(150,160,170)); c.addView(edit,lp(-1,54)); edit.setOnClickListener(v->showOrder()); r.addView(c,lp(-1,0)); setContentView(r); }

    private void showTracking(){ LinearLayout r=root(); title(r,"تتبع الطلب"); LinearLayout c=v(); c.setPadding(18,18,18,18); int q=prefs.getInt("quantity",quantity), total=prefs.getInt("total",price(q));
        TextView n=text("طلب رقم #1458\nالكمية: "+q+" جلكان\nالمجموع: "+total+" د.ع",20,TEXT,true); n.setBackground(bg(WHITE,18)); n.setPadding(18,14,18,14); c.addView(n,wrap(14));
        TextView steps=text("✓ تم إرسال الطلب\n\n✓ تم قبول الطلب\n\n🚚 جاري التوصيل\n\n○ تم التوصيل",19,TEXT,true); steps.setGravity(Gravity.RIGHT); steps.setBackground(bg(WHITE,18)); steps.setPadding(20,18,20,18); c.addView(steps,wrap(14));
        TextView loc=text("موقعك\n"+prefs.getString("location","غير محدد")+"\n\nأبو الماي بالطريق إلك 🚚",17,BLUE_DARK,true); loc.setBackground(bg(Color.rgb(232,243,251),18)); loc.setPadding(16,12,16,12); c.addView(loc,wrap(14)); Button back=button("الرئيسية",BLUE); c.addView(back,lp(-1,58)); back.setOnClickListener(v->showHome()); r.addView(c,lp(-1,0));setContentView(r); }

    private void showOrders(){ LinearLayout r=root(); title(r,"طلباتي"); LinearLayout c=v(); c.setPadding(18,18,18,18); String status=prefs.getString("status",""); if(status.isEmpty()) c.addView(text("ما عندك طلبات حالياً\n\nابدأ بطلب الماء من الرئيسية.",19,TEXT,true),wrap(200)); else {int q=prefs.getInt("quantity",1); TextView o=text("#1458\n"+q+" جلكان\n"+prefs.getInt("total",price(q))+" د.ع\n\n"+status,18,TEXT,true); o.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);o.setPadding(20,15,20,15);o.setBackground(bg(WHITE,18));c.addView(o,wrap(16)); Button track=button("متابعة الطلب",BLUE);c.addView(track,wrap(8));track.setOnClickListener(v->showTracking());} Button home=button("الرئيسية",Color.rgb(150,160,170));c.addView(home,lp(-1,56));home.setOnClickListener(v->showHome());r.addView(c,lp(-1,0));setContentView(r); }

    private void showAccount(){ LinearLayout r=root(); title(r,"حسابي"); LinearLayout c=v(); c.setPadding(18,18,18,18); c.addView(text("حساب العميل",22,TEXT,true),wrap(14));
        String phone=prefs.getString("phone",""); TextView info=text(phone.isEmpty()?"لم يتم تسجيل رقم الهاتف":"رقم الهاتف\n"+phone,18,TEXT,true); info.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); info.setPadding(18,12,18,12);info.setBackground(bg(WHITE,18));c.addView(info,wrap(10));
        Button login=button(phone.isEmpty()?"تسجيل الدخول برقم الهاتف":"تعديل رقم الهاتف",BLUE);c.addView(login,wrap(8));login.setOnClickListener(v->showLogin()); Button pay=button("💳 طرق الدفع",BLUE);c.addView(pay,wrap(8));pay.setOnClickListener(v->toast("يمكن إضافة Mastercard هنا عند ربط بوابة الدفع")); Button complaint=button("💬 الشكاوى والتواصل معنا",BLUE);c.addView(complaint,wrap(8));complaint.setOnClickListener(v->showComplaints()); Button home=button("الرئيسية",Color.rgb(150,160,170));c.addView(home,lp(-1,56));home.setOnClickListener(v->showHome());r.addView(c,lp(-1,0));setContentView(r); }

    private void showLogin(){ LinearLayout r=root();title(r,"تسجيل الدخول");LinearLayout c=v();c.setPadding(20,24,20,20);c.addView(text("ادخل رقم هاتفك",21,TEXT,true),wrap(12));EditText phone=new EditText(this);phone.setHint("رقم الهاتف");phone.setGravity(Gravity.RIGHT);phone.setInputType(2);c.addView(phone,wrap(10));Button send=button("إرسال كود التحقق",BLUE);c.addView(send,wrap(10));EditText code=new EditText(this);code.setHint("كود التحقق");code.setGravity(Gravity.RIGHT);code.setInputType(2);c.addView(code,wrap(10));Button enter=button("تأكيد الدخول",GREEN);c.addView(enter,wrap(10));enter.setOnClickListener(v->{prefs.edit().putString("phone",phone.getText().toString()).apply();showAccount();});c.addView(text("الكود SMS الحقيقي يحتاج ربط خدمة تحقق.",14,MUTED,false),lp(-1,60));r.addView(c,lp(-1,0));setContentView(r); }

    private void showComplaints(){ LinearLayout r=root();title(r,"الشكاوى والتواصل");LinearLayout c=v();c.setPadding(20,22,20,20);c.addView(text("اكتب رسالتك للإدارة",20,TEXT,true),wrap(10));EditText m=new EditText(this);m.setHint("اكتب الشكوى أو الملاحظة هنا...");m.setGravity(Gravity.RIGHT|Gravity.TOP);m.setMinLines(7);m.setPadding(14,12,14,12);m.setBackground(bg(WHITE,18));c.addView(m,wrap(12));Button send=button("إرسال الرسالة",BLUE);c.addView(send,wrap(8));send.setOnClickListener(v->{m.setText("تم استلام رسالتك ✓");m.setEnabled(false);});Button back=button("حسابي",Color.rgb(150,160,170));c.addView(back,lp(-1,56));back.setOnClickListener(v->showAccount());r.addView(c,lp(-1,0));setContentView(r); }

    private void showDriver(){ LinearLayout r=root();title(r,"أبو الماي");LinearLayout c=v();c.setPadding(18,18,18,18);c.addView(text("الطلبات الجديدة",21,TEXT,true),wrap(10));String status=prefs.getString("status","");if(status.isEmpty()){c.addView(text("ماكو طلبات جديدة حالياً",18,MUTED,true),wrap(160));}else{int q=prefs.getInt("quantity",1), total=prefs.getInt("total",price(q));TextView card=text("طلب #1458\n"+q+" جلكان\n"+total+" د.ع\nالموقع: "+prefs.getString("location","غير محدد"),18,TEXT,true);card.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);card.setPadding(18,15,18,15);card.setBackground(bg(WHITE,18));c.addView(card,wrap(12));Button accept=button("قبول الطلب",GREEN);c.addView(accept,wrap(8));accept.setOnClickListener(v->{prefs.edit().putString("status","جاري التوصيل").apply();showDriver();});Button map=button("📍 فتح موقع الزبون",BLUE);c.addView(map,wrap(8));map.setOnClickListener(v->showTracking());}Button home=button("الرئيسية",Color.rgb(150,160,170));c.addView(home,lp(-1,56));home.setOnClickListener(v->showHome());r.addView(c,lp(-1,0));setContentView(r); }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
