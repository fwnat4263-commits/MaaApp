# MaaAppAndroid

مشروع Android تجريبي لتطبيق Maa لتوصيل الماء.

## البناء

```bash
./gradlew assembleDebug
```

الناتج:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

يتم البناء تلقائياً عند push إلى `main` أو يدوياً من تبويب Actions، ثم يظهر APK كـArtifact باسم `Maa-debug-apk`.

> ملاحظة: ملف `gradlew` هنا Wrapper ذاتي التشغيل: إذا لم تكن نسخة Gradle موجودة، يقوم بتنزيل Gradle 9.6.0 ثم يشغله. توافق AGP 9.4.0 مع Gradle 9.6.0 وJDK 17 موثق من Android Developers.
