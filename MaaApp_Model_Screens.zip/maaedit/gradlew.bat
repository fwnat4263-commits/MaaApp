@echo off
setlocal
set "VERSION=9.6.0"
set "INSTALL=%USERPROFILE%\.gradle\maa-wrapper\gradle-%VERSION%"
if not exist "%INSTALL%\bin\gradle.bat" (
  if not exist "%INSTALL%" mkdir "%INSTALL%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%INSTALL%\gradle.zip'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%INSTALL%\gradle.zip' '%INSTALL%\unpacked'"
  for /d %%D in ("%INSTALL%\unpacked\gradle-*") do xcopy /E /I /Y "%%D\*" "%INSTALL%\" >nul
)
call "%INSTALL%\bin\gradle.bat" -p "%~dp0" %*
