package com.maaapp;

import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import java.util.List;
import java.util.Locale;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends Activity {
    private Typeface arabicFont;
    private final int BLUE = Color.rgb(13, 125, 210);
    private final int DARK = Color.rgb(25, 45, 65);
    private final int BG = Color.rgb(245, 249, 253);
    private final int GREEN = Color.rgb(31, 160, 91);
    private int quantity = 1;
    private double latitude = 0, longitude = 0;
    private String locationText = "لم يتم تحديد الموقع بعد";
    private LocationManager locationManager;
    private SharedPreferences prefs;
    private double driverLatitude = 0, driverLongitude = 0;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 101, 176));
        prefs = getSharedPreferences("maa", MODE_PRIVATE);
        try { arabicFont = Typeface.createFromAsset(getAssets(), "fonts/Omati Italic.otf"); } catch (Exception ignored) { arabicFont = Typeface.DEFAULT; }
        showHome();
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTypeface(arabicFont != null ? arabicFont : Typeface.DEFAULT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        return t;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setTextColor(Color.WHITE);
        b.setTypeface(arabicFont != null ? arabicFont : Typeface.DEFAULT); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setMinHeight(0); b.setPadding(12, 0, 12, 0); b.setBackground(bg(color, 24));
        return b;
    }

    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        return root;
    }

    private void showHome() {
        LinearLayout root = page();

        TextView top = text("💧  ماء", 28, Color.WHITE, true);
        top.setGravity(Gravity.CENTER);
        top.setBackground(bg(BLUE, 0));
        root.addView(top, new LinearLayout.LayoutParams(-1, 68));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18, 18, 18, 24);

        TextView welcome = text("هلا بيك 👋\\nاطلب ماي... يوصلك للبيت", 24, DARK, true);
        welcome.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, 82);
        content.addView(welcome, wp);

        android.widget.ImageView brandImage = new android.widget.ImageView(this);
        brandImage.setImageResource(com.maaapp.R.drawable.maa_app_image);
        brandImage.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        brandImage.setBackground(bg(Color.WHITE, 22));
        LinearLayout.LayoutParams bip = new LinearLayout.LayoutParams(-1, 215);
        bip.setMargins(0, 0, 0, 14);
        content.addView(brandImage, bip);

        TextView hero = text("🚚 أبو الماي بالطريق إلك\\nجلكان ماء 20 لتر", 21, Color.WHITE, true);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(16, 10, 16, 10);
        hero.setBackground(bg(BLUE, 22));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 82);
        hp.setMargins(0, 0, 0, 12);
        content.addView(hero, hp);

        Button order = button("💧  اطلب ماء الآن", BLUE);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, 64);
        op.setMargins(0, 0, 0, 14);
        content.addView(order, op);
        order.setOnClickListener(v -> showOrder());

        LinearLayout priceCard = new LinearLayout(this);
        priceCard.setOrientation(LinearLayout.VERTICAL);
        priceCard.setPadding(18, 12, 18, 12);
        priceCard.setBackground(bg(Color.WHITE, 20));

        TextView pt = text("أسعار الجلكانات", 19, DARK, true);
        pt.setGravity(Gravity.CENTER);
        priceCard.addView(pt, new LinearLayout.LayoutParams(-1, 38));

        TextView prices = text("1 جلكان   •   500 د.ع\\n2 جلكانات •   850 د.ع\\n3 جلكانات • 1,250 د.ع", 17, DARK, false);
        prices.setGravity(Gravity.CENTER);
        priceCard.addView(prices, new LinearLayout.LayoutParams(-1, 105));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, 150);
        pp.setMargins(0, 0, 0, 14);
        content.addView(priceCard, pp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(18, 12, 18, 12);
        info.setBackground(bg(Color.WHITE, 20));

        TextView it = text("شلون تطلب؟", 19, DARK, true);
        it.setGravity(Gravity.CENTER);
        info.addView(it, new LinearLayout.LayoutParams(-1, 38));

        TextView steps = text("① اختار عدد الجلكانات\\n② حدد موقعك على الخريطة\\n③ أكد الطلب\\n④ أبو الماي يوصله لبابك", 16, DARK, false);
        steps.setGravity(Gravity.CENTER);
        info.addView(steps, new LinearLayout.LayoutParams(-1, 130));
        content.addView(info);

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, 10, 0, 0);
        TextView orders = text("📋\\nطلباتي", 15, BLUE, true); orders.setGravity(Gravity.CENTER);
        TextView account = text("👤\\nحسابي", 15, BLUE, true); account.setGravity(Gravity.CENTER);
        TextView contact = text("📞\\nاتصل بنا", 15, BLUE, true); contact.setGravity(Gravity.CENTER);
        nav.addView(orders, new LinearLayout.LayoutParams(0, 70, 1));
        nav.addView(account, new LinearLayout.LayoutParams(0, 70, 1));
        nav.addView(contact, new LinearLayout.LayoutParams(0, 70, 1));
        content.addView(nav);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private int priceForQuantity(int q) {
        if (q == 1) return 500;
        if (q == 2) return 850;
        if (q == 3) return 1250;
        return q * 500;
    }

    private void showOrder() {
        LinearLayout root = page();
        TextView top = text("طلب ماء", 25, Color.WHITE, true);
        top.setGravity(Gravity.CENTER);
        top.setBackground(bg(BLUE, 0));
        root.addView(top, new LinearLayout.LayoutParams(-1, 68));

        ScrollView scroll = new ScrollView(this);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(18, 20, 18, 24);

        TextView title = text("جلكان ماء 20 لتر", 23, DARK, true);
        title.setGravity(Gravity.CENTER);
        c.addView(title, new LinearLayout.LayoutParams(-1, 58));

        TextView subtitle = text("اختار العدد اللي تريده", 17, Color.DKGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        c.addView(subtitle, new LinearLayout.LayoutParams(-1, 45));

        int[] nums = {1, 2, 3};
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, 8, 0, 8);

        TextView total = text("1 جلكان = 500 د.ع", 20, BLUE, true);
        total.setGravity(Gravity.CENTER);

        for (int n : nums) {
            Button b = button(n + (n == 1 ? " جلكان" : " جلكانات"), BLUE);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 70, 1);
            p.setMargins(5, 0, 5, 0);
            row.addView(b, p);
            final int x = n;
            b.setOnClickListener(v -> {
                quantity = x;
                total.setText(x + (x == 1 ? " جلكان = " : " جلكانات = ") + String.format(Locale.US, "%,d", priceForQuantity(x)) + " د.ع");
            });
        }
        c.addView(row, new LinearLayout.LayoutParams(-1, 86));
        c.addView(total, new LinearLayout.LayoutParams(-1, 70));

        Button next = button("📍  التالي: تحديد الموقع", BLUE);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, 64);
        np.setMargins(0, 12, 0, 10);
        c.addView(next, np);
        next.setOnClickListener(v -> showLocation());

        Button back = button("رجوع", Color.rgb(110, 120, 130));
        c.addView(back, new LinearLayout.LayoutParams(-1, 58));
        back.setOnClickListener(v -> showHome());

        scroll.addView(c);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void showLocation(){
        LinearLayout root=page();
        TextView top=text("حدد موقعك",25,Color.WHITE,true);top.setGravity(Gravity.CENTER);top.setBackground(bg(BLUE,0));root.addView(top,new LinearLayout.LayoutParams(-1,70));
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(24,24,24,24);
        TextView intro=text("📍 حتى يوصل أبو الماي لبابك، حدد موقعك الحالي",20,DARK,true); intro.setGravity(Gravity.RIGHT); c.addView(intro,new LinearLayout.LayoutParams(-1,80));
        TextView location=text("الموقع الحالي\n"+locationText,19,DARK,true); location.setGravity(Gravity.CENTER); location.setPadding(18,18,18,18); location.setBackground(bg(Color.WHITE,28)); c.addView(location,new LinearLayout.LayoutParams(-1,150));
        Button gps=button("📍 تحديد موقعي الآن",BLUE); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,65);gp.setMargins(0,18,0,10);c.addView(gps,gp);
        TextView coords=text("الإحداثيات: غير متوفرة",15,Color.DKGRAY,false);coords.setGravity(Gravity.CENTER);c.addView(coords,new LinearLayout.LayoutParams(-1,50));
        TextView hint=text("ملاحظة: فعّل الموقع (GPS) حتى نحدد مكانك بدقة.\nما نحتاج منك عنوان طويل.",16,Color.DKGRAY,false);hint.setGravity(Gravity.CENTER);c.addView(hint,new LinearLayout.LayoutParams(-1,90));
        Button confirm=button("تأكيد الموقع والمتابعة",GREEN);c.addView(confirm,new LinearLayout.LayoutParams(-1,65));
        gps.setOnClickListener(v -> requestCurrentLocation(location, coords));
        confirm.setOnClickListener(v -> { if(latitude==0 && longitude==0){ requestCurrentLocation(location, coords); } else { showConfirm(); }});
        Button back=button("رجوع",Color.GRAY);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,60);bp.setMargins(0,12,0,0);c.addView(back,bp);back.setOnClickListener(v->showOrder());
        root.addView(c,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }

    private void requestCurrentLocation(TextView location, TextView coords){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},100);
            return;
        }
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        boolean enabled=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if(!enabled){ location.setText("الموقع الحالي\nشغّل GPS من إعدادات الهاتف ثم اضغط مرة ثانية"); return; }
        LocationListener listener=new LocationListener(){
            @Override public void onLocationChanged(Location l){
                latitude=l.getLatitude(); longitude=l.getLongitude();
                locationText=reverseGeocode(latitude,longitude);
                location.setText("الموقع الحالي\n"+locationText);
                coords.setText(String.format(Locale.US,"الإحداثيات: %.6f , %.6f",latitude,longitude));
                locationManager.removeUpdates(this);
            }
        };
        try {
            if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,listener);
            else locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,1,listener);
            Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(last==null) last=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(last!=null) listener.onLocationChanged(last);
            location.setText("الموقع الحالي\nجاري تحديد موقعك...");
        } catch(SecurityException ignored) {}
    }

    private String reverseGeocode(double lat,double lon){
        try {
            Geocoder g=new Geocoder(this,Locale.forLanguageTag("ar"));
            List<Address> a=g.getFromLocation(lat,lon,1);
            if(a!=null && !a.isEmpty()){ Address x=a.get(0); String line=x.getAddressLine(0); if(line!=null && !line.isEmpty()) return line; }
        } catch(Exception ignored) {}
        return String.format(Locale.US,"%.6f , %.6f",lat,lon);
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==100 && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) showLocation();
    }

    private void showConfirm(){
        LinearLayout root=page(); TextView top=text("تأكيد الطلب",25,Color.WHITE,true);top.setGravity(Gravity.CENTER);top.setBackground(bg(BLUE,0));root.addView(top,new LinearLayout.LayoutParams(-1,70));
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(24,28,24,24);
        TextView card=text("📦  جلكانات: "+quantity+"\n💰  المجموع: "+priceForQuantity(quantity)+" د.ع\n📍  الموقع: "+locationText+"\n💳  الدفع: عند الاستلام",19,DARK,true);card.setPadding(24,24,24,24);card.setBackground(bg(Color.WHITE,28));c.addView(card,new LinearLayout.LayoutParams(-1,270));
        Button send=button("إرسال الطلب إلى أبو الماي",GREEN);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,68);sp.setMargins(0,24,0,12);c.addView(send,sp);
        send.setOnClickListener(v->{
            prefs.edit().putInt("quantity", quantity).putInt("total", priceForQuantity(quantity)).putString("location", locationText).putFloat("lat", (float)latitude).putFloat("lon", (float)longitude).putString("status", "جديد").apply();
            send.setText("تم إرسال الطلب ✓"); send.setEnabled(false);
            showCustomerStatus();
        });
        Button back=button("تعديل الطلب / الموقع",Color.GRAY);c.addView(back,new LinearLayout.LayoutParams(-1,60));back.setOnClickListener(v->showLocation());root.addView(c,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private void showCustomerStatus(){
        LinearLayout root=page();
        TextView top=text("حالة الطلب",25,Color.WHITE,true); top.setGravity(Gravity.CENTER); top.setBackground(bg(BLUE,0)); root.addView(top,new LinearLayout.LayoutParams(-1,70));
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(24,28,24,24);
        String status=prefs.getString("status","جديد");
        TextView card=text("📦 طلبك قيد المتابعة\n\n"+"الجلكانات: "+prefs.getInt("quantity",quantity)+"\n"+"المجموع: "+prefs.getInt("total",priceForQuantity(quantity))+" د.ع\n"+"📍 "+prefs.getString("location",locationText)+"\n\n"+"الحالة: "+status,20,DARK,true);
        card.setPadding(24,24,24,24); card.setBackground(bg(Color.WHITE,28)); c.addView(card,new LinearLayout.LayoutParams(-1,320));
        Button refresh=button("تحديث الحالة",BLUE); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,65); rp.setMargins(0,20,0,12); c.addView(refresh,rp);
        refresh.setOnClickListener(v->showCustomerStatus());
        Button home=button("الرئيسية",Color.GRAY); c.addView(home,new LinearLayout.LayoutParams(-1,60)); home.setOnClickListener(v->showHome());
        root.addView(c,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showDriver(){
        LinearLayout root=page();
        TextView top=text("🚚 أبو الماي",25,Color.WHITE,true); top.setGravity(Gravity.CENTER); top.setBackground(bg(DARK,0)); root.addView(top,new LinearLayout.LayoutParams(-1,70));
        ScrollView scroll=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(20,20,20,24);

        TextView mode=text("وضع الموزع\nسجّل موقعك حتى نعرف أقرب أبو ماي للطلب",18,DARK,true); mode.setGravity(Gravity.CENTER); mode.setPadding(18,18,18,18); mode.setBackground(bg(Color.WHITE,24)); c.addView(mode,new LinearLayout.LayoutParams(-1,120));
        Button gps=button("📍 تسجيل موقعي كموزع",BLUE); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,62);gp.setMargins(0,14,0,8);c.addView(gps,gp);
        TextView myloc=text("موقع الموزع: غير مسجل",15,Color.DKGRAY,false); myloc.setGravity(Gravity.CENTER); c.addView(myloc,new LinearLayout.LayoutParams(-1,55));
        gps.setOnClickListener(v->captureDriverLocation(myloc));

        String status=prefs.getString("status","");
        if(status.isEmpty() || status.equals("مكتمل") || status.equals("مرفوض")){
            TextView empty=text("ماكو طلبات جديدة حالياً\n\nمن يوصل طلب، راح يطلع هنا.",21,DARK,true); empty.setGravity(Gravity.CENTER); empty.setBackground(bg(Color.WHITE,28)); c.addView(empty,new LinearLayout.LayoutParams(-1,230));
        } else {
            int q=prefs.getInt("quantity",1), total=prefs.getInt("total",priceForQuantity(q)); String loc=prefs.getString("location","غير محدد");
            double clat=prefs.getFloat("lat",0), clon=prefs.getFloat("lon",0);
            double dist = (driverLatitude!=0 && clat!=0) ? distanceKm(driverLatitude,driverLongitude,clat,clon) : -1;
            String near = dist>=0 ? String.format(Locale.US,"\n📏 أنت تبعد عن الزبون %.1f كم",dist) : "\n📏 سجّل موقعك حتى نحسب المسافة";
            TextView order=text("🔔 طلب جديد\n\n📦 "+q+" جلكان 20 لتر\n💰 "+total+" د.ع\n📍 "+loc+near+"\n\nالحالة: "+status,19,DARK,true); order.setPadding(22,22,22,22); order.setBackground(bg(Color.WHITE,28)); c.addView(order,new LinearLayout.LayoutParams(-1,350));
            Button map=button("🗺️ فتح موقع الزبون بالخريطة",BLUE); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,62);mp.setMargins(0,14,0,8);c.addView(map,mp);
            map.setOnClickListener(v->openCustomerMap());
            Button accept=button("قبول الطلب ✓",GREEN); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,65); ap.setMargins(0,10,0,10); c.addView(accept,ap);
            Button reject=button("رفض الطلب",Color.rgb(190,70,70)); c.addView(reject,new LinearLayout.LayoutParams(-1,60));
            if(status.contains("جاري التوصيل")){
                accept.setText("تم التوصيل ✓"); reject.setVisibility(View.GONE);
                accept.setOnClickListener(v->{ prefs.edit().putString("status","مكتمل").apply(); showDriver(); });
            } else if(status.equals("جديد")) {
                accept.setOnClickListener(v->{ prefs.edit().putString("status","أبو الماي قبل الطلب - جاري التوصيل").apply(); showDriver(); });
                reject.setOnClickListener(v->{ prefs.edit().putString("status","مرفوض").apply(); showDriver(); });
            }
        }
        TextView nearest=text("🔎 نظام الأقرب\nالنسخة الحالية تحسب المسافة من موقع الموزع إلى الزبون. عند ربط قاعدة البيانات، راح نرسل الطلب تلقائياً لأقرب موزع متاح.",16,DARK,false); nearest.setPadding(18,18,18,18); nearest.setBackground(bg(Color.WHITE,24)); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,130);np.setMargins(0,18,0,0);c.addView(nearest,np);
        Button back=button("رجوع للواجهة الرئيسية",Color.GRAY); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,60); bp.setMargins(0,18,0,0); c.addView(back,bp); back.setOnClickListener(v->showHome());
        scroll.addView(c); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void captureDriverLocation(TextView view){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},200); return;
        }
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        try{
            Location l=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(l==null) l=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(l!=null){ driverLatitude=l.getLatitude(); driverLongitude=l.getLongitude(); prefs.edit().putFloat("driverLat",(float)driverLatitude).putFloat("driverLon",(float)driverLongitude).apply(); view.setText(String.format(Locale.US,"موقع الموزع: %.6f , %.6f",driverLatitude,driverLongitude)); return; }
            LocationListener dl=new LocationListener(){ @Override public void onLocationChanged(Location x){ driverLatitude=x.getLatitude(); driverLongitude=x.getLongitude(); prefs.edit().putFloat("driverLat",(float)driverLatitude).putFloat("driverLon",(float)driverLongitude).apply(); view.setText(String.format(Locale.US,"موقع الموزع: %.6f , %.6f",driverLatitude,driverLongitude)); locationManager.removeUpdates(this);} };
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,dl);
            view.setText("جاري تحديد موقع الموزع...");
        }catch(SecurityException ignored){}
    }

    private double distanceKm(double lat1,double lon1,double lat2,double lon2){
        double R=6371.0, dLat=Math.toRadians(lat2-lat1), dLon=Math.toRadians(lon2-lon1);
        double a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);
        return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
    }

    private void openCustomerMap(){
        double lat=prefs.getFloat("lat",0), lon=prefs.getFloat("lon",0);
        if(lat==0 && lon==0) return;
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.US,"geo:%f,%f?q=%f,%f(موقع الزبون)",lat,lon,lat,lon)));
        try{ startActivity(i); }catch(Exception ignored){}
    }

}
